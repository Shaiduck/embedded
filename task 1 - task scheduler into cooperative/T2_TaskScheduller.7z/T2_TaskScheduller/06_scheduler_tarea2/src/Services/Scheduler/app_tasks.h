/*******************************************************************************/
/**
\file       app_tasks.h
\brief      Tasks to be assigned to each execution thread of Task scheduler.
\author     Abraham Tezmol
\version    0.1
\date       10/Feb/2008
*/

#ifndef __APP_TASKS
#define __APP_TASKS

/*-- Includes ----------------------------------------------------------------*/
#include "compiler.h"
/* LED control definitions */ 
#include     "led_ctrl.h"

/*-- Variables -------------------------------------------------------*/

/*-- Defines -----------------------------------------------------------------*/

/*-- Macros ------------------------------------------------------------------*/

/* List of tasks to be executed @ 1ms */
/* AnMer - LED_Clear(1); //Tarea 1ms lista para ejecuci�n */
#define EXECUTE_1MS_TASKS()                 \
{											\
  /*    LED_Clear(1);*/ \ 
}
/* List of tasks to be executed @ 2ms, first group */
/* AnMer - LED_Clear(1); //Tarea 2ms_a lista para ejecuci�n */
#define EXECUTE_2MS_A_TASKS()				\
{											\
  /*    LED_Clear(1);*/ \ 
}
/* List of tasks to be executed @ 2ms, second group */
/* AnMer - LED_Clear(1); //Tarea 2ms_b lista para ejecuci�n */
#define EXECUTE_2MS_B_TASKS()				\
{											\
  /*    LED_Clear(1);*/ \ 
}
/* List of tasks to be executed @ 10ms */
/* AnMer - LED_Clear(1); //Tarea 10ms lista para ejecuci�n */ 
#define EXECUTE_10MS_TASKS()				\
{											\ 
  LED_Clear(1); \  
/*	vfnLedCtrl_BlinkingPattern();*/			\ 
}
/* List of tasks to be executed @ 50ms */
/* AnMer - LED_Clear(1); //Tarea 50ms lista para ejecuci�n */ 
#define EXECUTE_50MS_TASKS()				\
{											\
/*    LED_Clear(1);*/ \ 
}
/* List of tasks to be executed @ 100ms */
/* AnMer - LED_Clear(1); //Tarea 10ms lista para ejecuci�n */ 
#define EXECUTE_100MS_TASKS()				\
{											\
/*    LED_Clear(1);*/ \ 
}

/*============================================================================*/
#endif /*__APP_TASKS */
